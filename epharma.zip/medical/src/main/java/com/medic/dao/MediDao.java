package com.medic.dao;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.medic.model.Medicine;
import com.medic.repository.MediRepository;
import com.sun.el.parser.ParseException;

@Component
public class MediDao {
	@Autowired
	private MediRepository rep;
	
	public List<Medicine> getAll()   
	{  
	List<Medicine> medi = new ArrayList<Medicine>();  
	rep.findAll().forEach(medi1 -> medi.add(medi1));  
	return medi;  
	}  
	
	 public List<Medicine> getExp() throws ParseException {
		 List<Medicine> list = rep.findAll();
		 List<Medicine> list1=new ArrayList<Medicine>();
		 
		 Date date = new Date();  
		 SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
	      
		   
		for (Medicine medi : list) {
			if (sdf.format(date).compareTo(sdf.format(medi.getExpdate())) > 0)
			{
				// System.out.println(sdf.format(medi.getExpdate()));
				//System.out.println(sdf.format(date));
				list1.add(medi) ;	 
				}
					 
		}
		return list1;
     }
	 public void delete(int id)   
	   {  
	   rep.deleteById(id);  
	   }  
}
