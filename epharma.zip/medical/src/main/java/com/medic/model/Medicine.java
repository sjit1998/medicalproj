package com.medic.model;



import java.util.Calendar;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Past;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Range;
import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name = "medicine")

public class Medicine {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "id", nullable = false)
	private int id;
	
	@Column(name = "aname")
	@NotNull(message = "Name can not be null")
	@NotEmpty(message = "Name can not be empty")
	@Size(min = 3, max = 52, message = "Name must be min 3 max 50 characters")
	private String aname;
	
	@NotNull(message = "can not be null")
	@NotEmpty(message = "can not be empty")
	@Size(min = 3, max = 52, message = "Name must be min 3 max 50 characters")
	@Column(name = "com")
	private String com;
	
	
	
	@Column(name = "price", nullable = false)
	@NotNull(message = "can not be null")
	@Min(value=1,message = "must be greater than 1")
	private int price;
	
	
	
	//@NotNull(message = "can not be null")
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	@Temporal(TemporalType.DATE)
	@Column(name = "expdate")
    Date expdate;
	
	
	
	@Column(name = "qty", nullable = false)
	@NotNull(message = "can not be null")
	@Min(value=1,message = "must be greater than 1")
	private int qty;

	
	
	@Override
	public String toString() {
		return "Medicine [id=" + id + ", aname=" + aname + ", com=" + com + ", price=" + price + ", expdate=" + expdate
				+ ", qty=" + qty + "]";
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getAname() {
		return aname;
	}

	public void setAname(String aname) {
		this.aname = aname;
	}

	public String getCom() {
		return com;
	}

	public void setCom(String com) {
		this.com = com;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public Date getExpdate() {
		return expdate;
	}

	public void setExpdate(Date expdate) {
		this.expdate = expdate;
	}

	public int getQty() {
		return qty;
	}

	public void setQty(int qty) {
		this.qty = qty;
	}

	public Medicine() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Medicine(int id,
			@NotNull(message = "Name can not be null") @NotEmpty(message = "Name can not be empty") @Size(min = 3, max = 52, message = "Name must be min 3 max 50 characters") String aname,
			@NotNull(message = "can not be null") @NotEmpty(message = "can not be empty") @Size(min = 3, max = 52, message = "Name must be min 3 max 50 characters") String com,
			@NotNull(message = "can not be null") @Min(value = 1, message = "must be greater than 1") int price,
			Date expdate,
			@NotNull(message = "can not be null") @Min(value = 1, message = "must be greater than 1") int qty) {
		super();
		this.id = id;
		this.aname = aname;
		this.com = com;
		this.price = price;
		this.expdate = expdate;
		this.qty = qty;
	}

	/*public Medicine(int id,
			@NotNull(message = "Name can not be null") @NotEmpty(message = "Name can not be empty") @Size(min = 3, max = 52, message = "Name must be min 3 max 50 characters") String aname,
			@NotNull(message = "can not be null") @NotEmpty(message = "can not be empty") @Size(min = 3, max = 52, message = "Name must be min 3 max 50 characters") String com,
			@NotNull(message = "can not be null") @Min(value = 1, message = "must be greater than 1") int price,
			Date expdate,
			@NotNull(message = "can not be null") @Min(value = 1, message = "must be greater than 1") int qty) {
		super();
		this.id = id;
		this.aname = aname;
		this.com = com;
		this.price = price;
		this.expdate = expdate;
		this.qty = qty;
	}*/

	

	

	/*public Medicine(int id,
			@NotNull(message = "Name can not be null") @NotEmpty(message = "Name can not be empty") @Size(min = 3, max = 52, message = "Name must be min 3 max 50 characters") String aname,
			@NotNull(message = "can not be null") @NotEmpty(message = "Name can not be empty") String com,
			@NotNull(message = "can not be null") int price,  Date expdate,
			@NotNull(message = "can not be null") int qty) {
		super();
		this.id = id;
		this.aname = aname;
		this.com = com;
		this.price = price;
		this.expdate = expdate;
		this.qty = qty;
	}*/
	

	

	

	
	/*public Medicine(int id, String aname, String com, int price, Date expdate, int qty) {
		super();
		this.id = id;
		this.aname = aname;
		this.com = com;
		this.price = price;
		this.expdate = expdate;
		this.qty = qty;
	}*/
	
	
	

	

}
