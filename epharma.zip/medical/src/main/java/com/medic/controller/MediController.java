package com.medic.controller;

import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;



import com.medic.dao.MediDao;
import com.medic.model.Medicine;
import com.medic.repository.MediRepository;


@Controller
@RequestMapping("/")
public class MediController {
	
	@Autowired
	private MediRepository rep;
	@Autowired
	private MediDao dao;
	
	@GetMapping()
	public String welcome() {
		return "home";
	}
	
	@RequestMapping("/add")    
    public String showform(Model m){    
        m.addAttribute("medi", new Medicine());  
        return "mediform";   
    }  
	
	 @RequestMapping(value="/save",method = RequestMethod.POST)    
	    public String save(@Valid @ModelAttribute("medi") Medicine medi , BindingResult result){ 
		 //System.out.println(medi.getExpdate());
		 if (result.hasErrors()) {
				return "mediform";
			} else {
	         rep.save(medi);    
	        return "done";}
		 
	    }
	 @RequestMapping("/viewmedi")    
	    public String viewmed(Model m){    
	        List<Medicine> list=rep.findAll();    
	        m.addAttribute("list",list);  
	        return "showmedi";    
	    }   
	
	
	 /*@RequestMapping("/viewexp")    
	    public String viewexp(Model m)throws ParseException {
		 List<Medicine> list = rep.findAll();
		 List<Medicine> list1=new ArrayList<Medicine>();
		 
		 Date date = new Date();  
		 SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
	      
		   
		for (Medicine medi : list) {
			if (sdf.format(date).compareTo(sdf.format(medi.getExpdate())) > 0)
			{
				 System.out.println(sdf.format(medi.getExpdate()));
				System.out.println(sdf.format(date));
				list1.add(medi) ;	 
				}
					 
		}
		m.addAttribute("list1",list1); 
		 
		 return "showexp";
		 
	 }*/
	 @RequestMapping("/viewexp")    
	    public String viewexp(Model m, @ModelAttribute("medi") Medicine medi) throws Exception{
		 List<Medicine> list1=dao.getExp();
         m.addAttribute("list1",list1); 
		 
		 return "showexp";
	 }
	 @RequestMapping(value="/deletemedi",method = RequestMethod.GET)    
	    public String delete(@RequestParam int id){    
	    	dao.delete(id);     
	        return "done";    
	    }  
}
	

